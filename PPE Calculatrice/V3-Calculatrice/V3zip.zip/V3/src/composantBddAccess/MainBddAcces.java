package composantBddAccess;

import java.sql.SQLException;

public class MainBddAcces {

	public static void main(String[] args) {

		BddAccess bdd = new BddAccess();
		bdd.chargerDriver("com.mysql.jdbc.Driver");
		bdd.connectionBdd("mysql://localhost/", "eleves", "root", "");
		bdd.creerStatement();
		bdd.executeSelect("SELECT nom, prenom, age from eleves");
		bdd.recupererResultatRequete();

	}

}
