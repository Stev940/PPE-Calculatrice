package composantBddAccess;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JLabel;
import javax.swing.JPanel;

import vue.Ihm;

public class BddAccess {

	private Connection cnx;
	private Statement stmt;
	private ResultSet rs;
	private ResultSetMetaData resMeta;
	private Ihm ihm;
	
	//methodes
	
	
	public void chargerDriver(String pilote) {
		
		// recherche et chargement du driver approprie
		
		try {
			Class.forName(pilote);
			System.out.println("Driver trouve!");
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("Driver non trouve!");
		}
	}//fin methode chargerDriver
	
	
	public void connectionBdd(String localisationBdd, String bddName, String user, String password) {
		
		//etablissement a la connexion de la base de donnee
		
		try {
			cnx = DriverManager.getConnection("jdbc:"+localisationBdd+ bddName, user, password);
		} catch (SQLException e) {
			System.out.println("pb connection bdd "+bddName);
			e.printStackTrace();
		}
		System.out.println("connexion bdd"+ bddName+ " ok!");
		
	}//fin methode connectionBdd
	
	
	
	public void creerStatement() {
		
		//creation d'un objet statement
		
		try {
			stmt = cnx.createStatement();
		}catch(SQLException e) {
			System.out.println("pb creation statement");
			e.printStackTrace();
		}
	}//fin methode creerStatement
	
	
	
	public void executeSelect(String requete) {
		try {
			rs = stmt.executeQuery(requete);
		} catch (SQLException e) {
			System.out.println("pb avec la requete!!");
			e.printStackTrace();
		}
	}
	
	public void executeUpdate(String requete) {
		try {
			stmt.executeUpdate(requete);
		} catch (SQLException e) {
			System.out.println("pb avec la requete!!");
			e.printStackTrace();
		}
	}
	
	public void recupererResultatRequete(JPanel pan)  {
		//resMeta permet de recuperer de rs les meta data c a d la structure des donn�es elles memes
		try {
			resMeta = rs.getMetaData();
			
			//recuperation du nb de colonnes de la reponse
			
			int nbCols = resMeta.getColumnCount();
			
			//affichage des noms des colonnes
			for (int i = 1; i <= nbCols; i++) {
				System.out.print(resMeta.getColumnName(i) + "    |    ");
			}
			
			System.out.println();
			
			//traitement de la reponse
			while(rs.next()){
				for (int i = 1; i <= nbCols; i++) {
					System.out.print(rs.getObject(i).toString()+"        ");
					JLabel infoEleve = new JLabel(rs.getObject(i).toString());
					pan.add(infoEleve);
				}
				System.out.println();
			}
		}catch(SQLException e) {
			System.out.println("pb dans le traitement du resultat de la requete!!");
			e.printStackTrace();
		}
		
	}//fin methode recupererResultatRequete
	
	public void setIhm(Ihm ihm) {
		this.ihm = ihm;
	}
	
	
}//fin classe
