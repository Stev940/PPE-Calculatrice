package controleur;

import java.awt.event.ActionEvent;

import Modele.Modele;
import vue.Ihm;
import vue.Vue;

public class Controleur {
	
	// Attributs
	private Modele modele;
	private Vue vue;
	private Ihm ihm;
	private int nb1;
	private int nb2;
	public int choixEleve;
	public int resultat;
	private boolean perdu;
	private int clic;
	
	
	//m�thodes
	
	public void controlEvent (ActionEvent evt, Ihm ihm) {
		this.ihm = ihm;
		nb1 = (int) (Math.random()*10);
		//traitement addition
		if (evt.getSource() == ihm.getBoutonPlus()) {
			vue.afficherAddition(nb1, nb2 = randomPlus(nb1));
			resultat = modele.getAddition(nb1, nb2);
		//traitement soustraction
		} else if (evt.getSource() == ihm.getBoutonMoins()) {
			vue.afficherSoustraction(nb1, nb2 = randomMoins(nb1));
			resultat = modele.getSoustraction(nb1, nb2);
		//traitement des boutons chiffres
		} else if(evt.getSource() == ihm.getBouton1()) {
			ihm.getSaisie().setText(ihm.getBouton1().getText());
			choixEleve = Integer.parseInt(ihm.getBouton1().getText());
		}else if(evt.getSource() == ihm.getBouton2()) {
			ihm.getSaisie().setText(ihm.getBouton2().getText());
			choixEleve = Integer.parseInt(ihm.getBouton2().getText());
		}else if(evt.getSource() == ihm.getBouton3()) {
			ihm.getSaisie().setText(ihm.getBouton3().getText());
			choixEleve = Integer.parseInt(ihm.getBouton3().getText());
		}else if(evt.getSource() == ihm.getBouton4()) {
			ihm.getSaisie().setText(ihm.getBouton4().getText());
			choixEleve = Integer.parseInt(ihm.getBouton4().getText());
		}else if(evt.getSource() == ihm.getBouton5()) {
			ihm.getSaisie().setText(ihm.getBouton5().getText());
			choixEleve = Integer.parseInt(ihm.getBouton5().getText());
		}else if(evt.getSource() == ihm.getBouton6()) {
			ihm.getSaisie().setText(ihm.getBouton6().getText());
			choixEleve = Integer.parseInt(ihm.getBouton6().getText());
		}else if(evt.getSource() == ihm.getBouton7()) {
			ihm.getSaisie().setText(ihm.getBouton7().getText());
			choixEleve = Integer.parseInt(ihm.getBouton7().getText());
		}else if(evt.getSource() == ihm.getBouton8()) {
			ihm.getSaisie().setText(ihm.getBouton8().getText());
			choixEleve = Integer.parseInt(ihm.getBouton8().getText());
		}else if(evt.getSource() == ihm.getBouton9()) {
			ihm.getSaisie().setText(ihm.getBouton9().getText());
			choixEleve = Integer.parseInt(ihm.getBouton9().getText());
		}else if(evt.getSource() == ihm.getBouton10()) {
			ihm.getSaisie().setText(ihm.getBouton10().getText());
			choixEleve = Integer.parseInt(ihm.getBouton10().getText());
		//traitement du bouton valider
		}else if(evt.getSource() == ihm.getBoutonValider()) {
			comparerResultat();
			messageIhm(perdu);
			
		}
			
	}
	
	public void messageIhm(boolean perdu) {
		if(perdu) {
			clic+=1;
			if(clic == 3) {
				ihm.getSaisie().setText("La bonne r�ponse �tait "+resultat);
				clic = 0;
			} else {
				ihm.getSaisie().setText("mauvais r�sultat");
			}
		} else {
			ihm.getSaisie().setText("Bravo!");
		}
	}
	
	public void comparerResultat() {
		if(choixEleve == resultat) {
			perdu = false;
			clic = 0;
		} else {
			perdu = true;
		}
	}
	
	public int randomPlus(int nombre) {
		int nb2 = (int) ((10 - nombre) * Math.random());
		return nb2;
	}
	
	public int randomMoins(int nombre) {
		int nb2 = (int) (nombre * Math.random());
		return nb2;
	}
	
	public void setModele (Modele modele) {
		this.modele = modele;
	}
	
	
	public void setVue (Vue vue) {
		this.vue = vue;
	}
	
	
	

}
