package Modele;

import composantBddAccess.BddAccess;

public class Modele {
	
	//Attributs
	private int resultat;
	private BddAccess bdd;
	
	
	//m�thodes
	public int getAddition(int nb1, int nb2) {
		resultat = nb1 + nb2;
		return resultat;
	}
	
	public int getSoustraction(int nb1, int nb2) {
		resultat = nb1 - nb2;
		return resultat;
	}
	
	
	
	
}
