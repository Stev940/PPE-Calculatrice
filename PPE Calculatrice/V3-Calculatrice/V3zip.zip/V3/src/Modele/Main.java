package Modele;

import composantBddAccess.BddAccess;
import controleur.Controleur;
import vue.Ihm;
import vue.Vue;

public class Main {

	public static void main(String[] args) {
		
		
		Modele modele = new Modele();
		Controleur controleur = new Controleur();
		Ihm ihm = new Ihm();
		Vue vue = new Vue();
		BddAccess bdd = new BddAccess();
		
		ihm.setControleur(controleur);
		controleur.setModele(modele);
		controleur.setVue(vue);
		vue.setIhm(ihm);
		bdd.setIhm(ihm);
		
		
		
		
	}

}
