package Model;

public class Modele {
	
	//Attributs
	private int resultat;
	
	
	//m�thodes
	public int getAddition(int nb1, int nb2) {
		resultat = nb1 + nb2;
		return resultat;
	}
	
	public int getSoustraction(int nb1, int nb2) {
		resultat = nb1 - nb2;
		return resultat;
	}
	
}
