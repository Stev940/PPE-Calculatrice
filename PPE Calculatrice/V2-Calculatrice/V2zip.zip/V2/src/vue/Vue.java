package vue;

public class Vue {
	
	private Ihm ihm;

	public void afficherAddition(int nb1, int nb2) {
		ihm.afficherAddition(nb1, nb2);
	}
	
	public void afficherSoustraction(int nb1, int nb2) {
		ihm.afficherSoustraction(nb1, nb2);
	}
	
	public void setIhm(Ihm ihm) {
		this.ihm = ihm;
	}
	
}
