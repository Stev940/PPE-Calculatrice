package vue;

import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controleur.Controleur;
import modele.Modele;
import vue.Vue;
import vue.CalculetteGraphique.EqualListener;
import vue.CalculetteGraphique.NumbersListener;
import vue.CalculetteGraphique.SignsListener;

public class Ihm extends JFrame implements ActionListener {
	
	//attributs
	
	private JPanel panel;

	private JLabel choix = new JLabel("choisis ton op�ration :");
	private JButton boutonPlus = new JButton("Addition");
	private JButton boutonMoins = new JButton("Soustraction");
	private JButton boutonValider = new JButton("Valider");
	private JLabel labelResultat = new JLabel("<< R�sultat");
	private JLabel labelOperation = new JLabel("coucou");
	private JLabel labelSaisie = new JLabel();
	private JLabel bravo_erreur;
	private Controleur controleur;
	
	
	//Attributs sp�cifiques au clavier
	private JButton bouton0, bouton1, bouton2, bouton3, bouton4, bouton5, bouton6, bouton7, bouton8, bouton9, bouton10, bouton11;
	private JPanel panelTouches = new JPanel(new GridLayout(5, 3));

	//constructeur de la fenetre
	public Ihm() {
		// Creer le Panel
		panel = new JPanel();
		
		//rendre la fenetre visible
		setVisible(true);
		
		//definir un titre pour le cadre
		setTitle("IHM");
		
		//definir une taille (1er longeur, 2er hauteur)
		setSize(500, 500);
		
		//on ne peut pas modifier la taille de la fenetre
		setResizable(false);
				
		//fenetre centrer
		setLocationRelativeTo(null);
		
		// terminer le processus lorsque l'on clique "fermer"
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel.setBackground(Color.pink);
			
		//attribuer ce panel a la fenetre
		setContentPane(panel);
		panel.add(choix);
		panel.add(boutonPlus);
		panel.add(boutonMoins);
		panel.add(labelOperation);
		boutonPlus.addActionListener(this);
		boutonMoins.addActionListener(this);
		boutonValider.addActionListener(this);
		afficherClavier();
	}
		
		
	
		//m�thodes
		
	
		public void afficherResultat(int resultat) {
			labelSaisie.setText(""+resultat);
		}
		
		public void afficherAddition(int nb1, int nb2) {
			labelOperation.setText("Combien font "+nb1+" + "+nb2+ "?");
		}
		
		public void afficherSoustraction(int nb1, int nb2) {
			labelOperation.setText("Combien font "+nb1+" - "+nb2+ "?");
		}
		
		public void setControleur(Controleur controleur) {
			this.controleur = controleur;
		}
		
		public JButton getBoutonPlus() {
			return boutonPlus;
		}
		
		public JButton getBoutonMoins() {
			return boutonMoins;
		}
		
		public JButton getBoutonValider() {
			return boutonValider;
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			
			controleur.controlEvent(e, this);
			
		}
		
		public JLabel getSaisie() {
			return labelSaisie;
		}
	
		
		public void afficherClavier() {
			
			bouton0 = new JButton("0");
			panelTouches.add(bouton0);
			bouton0.addActionListener(this);
			bouton1 = new JButton("1");
			panelTouches.add(bouton1);
			bouton1.addActionListener(this);
			bouton2 = new JButton("2");
			panelTouches.add(bouton2);
			bouton2.addActionListener(this);
			bouton3 = new JButton("3");
			panelTouches.add(bouton3);
			bouton3.addActionListener(this);
			bouton4 = new JButton("4");
			panelTouches.add(bouton4);
			bouton4.addActionListener(this);
			bouton5 = new JButton("5");
			panelTouches.add(bouton5);
			bouton5.addActionListener(this);
			bouton6 = new JButton("6");
			panelTouches.add(bouton6);
			bouton6.addActionListener(this);
			bouton7 = new JButton("7");
			panelTouches.add(bouton7);
			bouton7.addActionListener(this);
			bouton8 = new JButton("8");
			panelTouches.add(bouton8);
			bouton8.addActionListener(this);
			bouton9 = new JButton("9");
			panelTouches.add(bouton9);
			bouton9.addActionListener(this);
			bouton10 = new JButton("10");
			panelTouches.add(bouton10);
			bouton10.addActionListener(this);
			bouton11 = new JButton("");
			panelTouches.add(bouton11);
		
			panel.add(panelTouches);
			panel.add(labelSaisie);
			panel.add(labelResultat);
			panel.add(boutonValider);
			
		}
		
		public JButton getBouton0() {
			return bouton0;
		}
		
		public JButton getBouton1() {
			return bouton1;
		}
		
		public JButton getBouton2() {
			return bouton2;
		}
		
		public JButton getBouton3() {
			return bouton3;
		}
		
		public JButton getBouton4() {
			return bouton4;
		}
		
		public JButton getBouton5() {
			return bouton5;
		}
		
		public JButton getBouton6() {
			return bouton6;
		}
		
		public JButton getBouton7() {
			return bouton7;
		}
		
		public JButton getBouton8() {
			return bouton8;
		}
		
		public JButton getBouton9() {
			return bouton9;
		}
		
		public JButton getBouton10() {
			return bouton10;
		}



		public JLabel getBravo_erreur() {
			return bravo_erreur;
		}



		
		
		
		
		
		

}
