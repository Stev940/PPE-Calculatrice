package Model;

public class Modele {
	
	//Attributs
	private int resultat;
	
	
	//m�thodes
	public int getAddition(int nb1, int nb2) {
		return resultat = nb1 + nb2;
	}
	
	public int getSoustraction(int nb1, int nb2) {
		return resultat = nb1 - nb2;
	}
	
}
