package controleur;

import java.awt.event.ActionEvent;
import Model.Modele;
import vue.Ihm;
import vue.Vue;

public class Controleur extends Thread{
	
	// Attributs
	private Modele modele;
	private Vue vue;
	private int nb1;
	private int nb2;
	private int resultat;
	monThread thread = new monThread();
	
	
	//m�thodes
	
	public void controlEvent (ActionEvent evt, Ihm ihm) {
		nb1 = (int) (Math.random()*10);
		if (evt.getSource() == ihm.getBoutonPlus()) {
			ihm.afficherClavier();
			vue.afficherAddition(nb1, randomPlus(nb1));
			resultat = modele.getAddition(nb1, nb2);
		} else if (evt.getSource() == ihm.getBoutonMoins()) {
			ihm.afficherClavier();
			vue.afficherSoustraction(nb1, randomMoins(nb1));
			resultat = modele.getSoustraction(nb1, nb2);
		} else if(evt.getSource() == ihm.getBouton1()) {
			ihm.getSaisie().setText(ihm.getBouton1().getText());
		}else if(evt.getSource() == ihm.getBouton2()) {
			ihm.getSaisie().setText(ihm.getBouton2().getText());
		}else if(evt.getSource() == ihm.getBouton3()) {
			ihm.getSaisie().setText(ihm.getBouton3().getText());
		}else if(evt.getSource() == ihm.getBouton4()) {
			ihm.getSaisie().setText(ihm.getBouton4().getText());
		}else if(evt.getSource() == ihm.getBouton5()) {
			ihm.getSaisie().setText(ihm.getBouton5().getText());
		}else if(evt.getSource() == ihm.getBouton6()) {
			ihm.getSaisie().setText(ihm.getBouton6().getText());
		}else if(evt.getSource() == ihm.getBouton7()) {
			ihm.getSaisie().setText(ihm.getBouton7().getText());
		}else if(evt.getSource() == ihm.getBouton8()) {
			ihm.getSaisie().setText(ihm.getBouton8().getText());
		}else if(evt.getSource() == ihm.getBouton9()) {
			ihm.getSaisie().setText(ihm.getBouton9().getText());
		}else if(evt.getSource() == ihm.getBouton10()) {
			ihm.getSaisie().setText(ihm.getBouton10().getText());
		}else if(evt.getSource() == ihm.getBoutonValider()) {
			ihm.getSaisie().setText("");
			
		}
			
	}
	
	public int randomPlus(int nombre) {
		int nb2 = (int) ((10 - nombre) * Math.random());
		return nb2;
	}
	
	public int randomMoins(int nombre) {
		int nb2 = (int) (nombre * Math.random());
		return nb2;
	}
	
	public void setModele (Modele modele) {
		this.modele = modele;
	}
	
	
	public void setVue (Vue vue) {
		this.vue = vue;
	}
	
	
	

}
